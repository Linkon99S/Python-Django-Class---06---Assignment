from django.urls import path
from . import views

urlpatterns = [
    path('', views.course),
    path('ds/', views.data_science),
    path('ml/', views.machine_learning),
    path('dl/', views.deep_learning),
    path('bd/', views.big_data),
]
