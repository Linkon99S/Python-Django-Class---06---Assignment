from django.shortcuts import render

# Create your views here.
def free_course(request):
    return render(request,'freecourse.html')

def blog(request):
    return render(request,'blog.html')